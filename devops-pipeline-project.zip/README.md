# 🚀 DevOps Pipeline Project

This repo contains a sample Flask app with:
- Dockerfile for containerization
- Jenkinsfile for CI/CD via Jenkins
- GitHub Actions Workflow for automated builds
